<?php
	defined('security') or die('Access denied'); // Add light protection against file access
?>

<div class="page-content">
	<div class="container">
		<h1 class="page-title">404 page</h1>
	</div>
</div>

