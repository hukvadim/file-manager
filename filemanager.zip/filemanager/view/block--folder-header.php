<?php
	defined('security') or die('Access denied'); // Add light protection against file access
?>
<div class="folder-list-header d-flex-sides">
	<div class="folder-list-header__left d-flex-side-left">
		<label class="form-check-label checkbox-file">
			<input class="form-check-input" type="checkbox" value="">
		</label>
		<div class="btn-folder-group w-100">
			<ul class="nav nav-pills nav-files w-100 js-box-folder-group">
			
				<!-- Вивід через js -->

			</ul>
		</div>
	</div>
</div>