<?php
defined('security') or die('Access denied'); // Add light protection against file access

$lang['error__filePathKey'] = 'Invalid file path key: $filePathKey';
$lang['error__controller'] = 'Controller not found!';

$lang['titlePart'] = '| Файловий менеджер';
$lang['pageTitle404']  = 'Помилка 404';
$lang['pageTitleHome'] = 'Головна';

$lang['blockNoResult'] = 'Результатів не знайдено';
